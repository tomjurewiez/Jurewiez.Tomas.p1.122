
package parcial;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;


public class RestauranteGourmet {
    private final List<Plato> platos = new ArrayList<>();
    
    
    public void agregarPlato(Plato nuevoPlato) throws PlatoDuplicadoException{
        for(Plato p: platos){
            if(p.getClass().equals(nuevoPlato.getClass()) && p.getNombre().equalsIgnoreCase(nuevoPlato.getNombre())){
                throw new PlatoDuplicadoException("Ya existe tipo de plato " + 
                        p.getClass().getSimpleName() + "Nombre: " + p.getNombre() + ".");
            }       
        }
    platos.add(nuevoPlato);
    }
    
    public void mostrarPlatos(){
        for (Plato p : platos){
            System.out.println(p);
        }
    }
    
    public void prepararPlato(String nombre){
        Plato plato = buscarPlatoPorNombre(nombre);
        if (plato != null && plato instanceof Preparable){
            ((Preparable) plato).preparar();
            }else{
            System.out.println("El plato  " + nombre + " no es preparable");
        }
    }
    
    public void decorarPlato(String nombre){
        Plato plato = buscarPlatoPorNombre(nombre);
        if ( plato != null && plato instanceof Decorable){
            ((Decorable) plato).decorar();
            }else{
            System.out.println("El plato  " + nombre + " no es preparable");
        }
    }
    
    public void filtrarPorTipoPreparacion(TipoPreparacion tipo){
        for (Plato p : platos){
            if(p.getTipoDePreparacion() == tipo){
                System.out.println(p);
            }
        }
    }
       
    public void mostrarPlatoPorTipo(String tipoDePlato){
        for(Plato p : platos){
            if (p.getClass().getSimpleName().equals(tipoDePlato)){
                System.out.println(p);
            }
    }
    }
    
    
    private Plato buscarPlatoPorNombre(String nombre){
        for(Plato p : platos){
            if(p.getNombre().equalsIgnoreCase(nombre)){
                return p;
            }
        }
        throw new NoSuchElementException("No se encontro plato: " + nombre +  ".");
    }
    
        
    
    

    
    
    
    
}
