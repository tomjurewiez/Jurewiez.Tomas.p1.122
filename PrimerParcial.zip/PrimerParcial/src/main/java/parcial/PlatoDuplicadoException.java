
package parcial;


public class PlatoDuplicadoException extends Exception{
 
    public PlatoDuplicadoException(String mensaje){
        super(mensaje);
    }
}
