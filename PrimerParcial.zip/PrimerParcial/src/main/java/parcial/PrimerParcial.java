    
package parcial;

public class PrimerParcial {
    public static void main(String[] args) {
        RestauranteGourmet restaurante = new RestauranteGourmet();

        try {
           
            Plato entrada = new Entrada("Bruschetta", 1200.0, TipoPreparacion.FRIA, 7);
            Plato principal = new PlatoPrincipal("Risotto", 2500.0, TipoPreparacion.CALIENTE, 15);
            Plato postre = new Postre("Tiramisú", 1500.0, TipoPreparacion.FRIA, true);

            
            restaurante.agregarPlato(entrada);
            restaurante.agregarPlato(principal);
            restaurante.agregarPlato(postre);

            
            System.out.println("\nMenú completo:");
            restaurante.mostrarPlatos();

            
            System.out.println("\nPreparando platos:");
            restaurante.prepararPlato("Bruschetta");
            restaurante.prepararPlato("Risotto");

            
            System.out.println("\nDecorando platos:");
            restaurante.decorarPlato("Bruschetta");
            restaurante.decorarPlato("Tiramisú");

            
            System.out.println("\nPlatos calientes:");
            restaurante.filtrarPorTipoPreparacion(TipoPreparacion.CALIENTE);

            
            System.out.println("\nSolo entradas:");
            restaurante.mostrarPlatoPorTipo("Entrada");

        } catch (PlatoDuplicadoException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error inesperado: " + e.getMessage());
        }
    }
}