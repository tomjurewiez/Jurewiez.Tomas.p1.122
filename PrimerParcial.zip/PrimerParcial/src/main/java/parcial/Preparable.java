
package parcial;


public interface Preparable {
    public void preparar();
}
