
package parcial;


public class Postre extends Plato implements Decorable {
    private boolean contieneAzucar;

    public Postre(String nombre, double precio, TipoPreparacion tipoPreparacion, boolean contieneAzucar) {
        super(nombre, precio, tipoPreparacion);
        this.contieneAzucar = contieneAzucar;
    }



    @Override
    public void decorar() {
        System.out.println(getNombre() + " Se esta decorando");
    }

    
    @Override
    public String toString() {
        return String.format("Postre: %s | Precio: $%.2f | Preparacion: %s | Contiene azucar: %s", 
                    getNombre(), getPrecio(), getTipoDePreparacion() , contieneAzucar ? "Si" : "No");  
    }
    
    
      
    
    
    
}
