
package parcial;


public class Entrada extends Plato implements Preparable,Decorable{
    private Integer cantidadIngredientes;

    public Entrada(String nombre, double precio, TipoPreparacion tipoPreparacion,Integer cantidadIngredientes) {
        super(nombre, precio, tipoPreparacion);
        this.cantidadIngredientes = cantidadIngredientes;
    }
    
    @Override
    public void preparar(){
        System.out.println(getNombre() + " se esta preparando");
    }
    
    @Override
    public void decorar(){
        System.out.println(getNombre() + " Se esta decorando");
    }

    @Override
    public String toString() {
     return String.format("Entrada: %s | Precio: $%.2f | Preparacion: %s | Ingredientes: %d", 
             getNombre(), getPrecio(), getTipoDePreparacion() , cantidadIngredientes);   
    }

    
    
    
    
    
    
}
