
package parcial;


public interface Decorable {
    public void decorar();
}
