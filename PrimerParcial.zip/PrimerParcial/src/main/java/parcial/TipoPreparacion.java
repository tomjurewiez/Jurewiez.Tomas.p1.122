
package parcial;


public enum TipoPreparacion {
    CALIENTE,
    FRIA
}
