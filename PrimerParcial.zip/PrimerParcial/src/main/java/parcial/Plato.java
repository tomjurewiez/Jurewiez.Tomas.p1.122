
package parcial;


public abstract class Plato {
    private String nombre;
    private double precio;
    private TipoPreparacion tipoPreparacion;

    public Plato(String nombre, double precio, TipoPreparacion tipoPreparacion) {
        this.nombre = nombre;
        this.precio = precio;
        this.tipoPreparacion = tipoPreparacion;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public double getPrecio(){
        return precio;
    }
    
    public TipoPreparacion getTipoDePreparacion(){
        return tipoPreparacion;
    }
    
    
    @Override
   public String toString(){
       return String.format("Plato Principal: %s | Precio: $%.2f | Preparacion: %s", 
                    getNombre(), getPrecio(), getTipoDePreparacion());
   }
    
}
