
package parcial;


public class PlatoPrincipal extends Plato implements Preparable {
    private Integer tiempoDeCoccion;

    public PlatoPrincipal(String nombre, double precio, TipoPreparacion tipoPreparacion,Integer tiempoDeCoccion) {
        super(nombre, precio, tipoPreparacion);
        this.tiempoDeCoccion = tiempoDeCoccion;
    }
    

    @Override
    public void preparar(){
        System.out.println(getNombre() + " Se esta preparando " + "Tiempo Estimado: " + tiempoDeCoccion + " Min");
    }
    
    @Override
    public String toString() {
        return String.format("Plato Principal: %s | Precio: $%.2f | Preparacion: %s | Coccion: %d Min", 
                    getNombre(), getPrecio(), getTipoDePreparacion() , tiempoDeCoccion);  
    }
    
    
    
}
